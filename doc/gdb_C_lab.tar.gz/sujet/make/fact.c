#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <inttypes.h>

int64_t fact(int n){
    assert(n >= 0);
    if (n==0)
        return 1;
    else {
        int64_t r = fact(n-1);
        return n * r;
    }
}

int main(int argc, char* argv[]){
    assert(argc==2);
    int limit = atoi(argv[1]);
    int64_t result = 0;
    for (int i = 0; i < 100; i++){
        result = fact(limit);
    }
    printf("fact(%d) = %" PRId64 "\n", limit, result);

    return EXIT_SUCCESS;
}
