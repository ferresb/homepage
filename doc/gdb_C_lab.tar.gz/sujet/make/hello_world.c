#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
    printf("Hello World!\n");
    return EXIT_SUCCESS;
}
