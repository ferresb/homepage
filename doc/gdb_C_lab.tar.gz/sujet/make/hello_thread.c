#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void* my_func(void* arg){
    printf("Hello_world\n");
}

int main(int argc, char* argv[]){
    pthread_t th;
    pthread_create(&th, NULL, my_func, NULL);
    return EXIT_SUCCESS;
}
