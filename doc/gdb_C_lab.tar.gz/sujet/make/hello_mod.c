#include <stdio.h>
#include <stdlib.h>

extern void my_printf();

int main(int argc, char* argv[]){
    my_printf();
    return EXIT_SUCCESS;
}
