#include <stdio.h>
#include <stdlib.h>

void my_printf(){
    printf("Hello World!\n");
}
