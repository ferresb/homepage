#include <stdlib.h>
#include <stdio.h>

typedef struct _node {
    int value;
    struct _node* left;
    struct _node* right;
} node;

void insert(node** tree, int value) {
    if (!(*tree)){
        node* root = malloc(sizeof(root));
        root->value = value;
        root->left = NULL;
        root->right = NULL;
        (*tree) = root;
        return;
    }
    if (value > (*tree)->value){
        insert(&((*tree)->right), value);
    }
    if (value < (*tree)->value){
        insert((*tree)->left, value);
    }
}

void depth_print(node* tree){
    printf("%d;", tree->value);
    depth_print(tree->left);
    depth_print(tree->right);
}

void free_tree(node* tree){
    if (tree != NULL) {
        free(tree);
        free_tree(tree->left);
        free_tree(tree->right);
    }
}

node* from_array(int size, int* array){
    node* root;
    for (int i = 0; i < size; i++){
        insert(&root, array[i]);
    }
    return root;
}

int main(void* arg){
    node* tree;
    insert(&tree, 4);
    insert(&tree, 2);
    insert(&tree, 7);
    insert(&tree, 8);
    depth_print(tree);
    printf("\n");
    free_tree(tree);
    int array[6] = {0, 3, 5, 15, 4, 2};
    tree = from_array(6, array); 
    depth_print(tree);
    printf("\n");
    free_tree;
    exit(EXIT_SUCCESS);
}
