import sys

TGT_CLK=10.0

def main(timing, resources, report):
    with open(timing, 'r') as f:
        timing_content = f.readlines()
    with open(resources, 'r') as f:
        resources_content = f.readlines()
    for line in timing_content:
        line = line.strip()
        if line.startswith("Slack"):
            try:
                slack = float(line.split(":")[1].strip().split("ns")[0].strip())
                delay = TGT_CLK-slack
                freq  = (1000.0/delay)
            except:
                slack = -1.0
                delay = -1.0
                freq  = -1.0
    for line in resources_content:
        line = line.strip()
        if "LUT as Logic" in line:
            tmp = line.split("|")
            lut_used = int(tmp[2].strip())
            lut_perc = float(tmp[6].strip())
        if "Register as Flip Flop" in line:
            tmp = line.split("|")
            ff_used = int(tmp[2].strip())
            ff_perc = float(tmp[6].strip())
        if ("Block RAM Tile" in line) and line.startswith("|"):
            tmp = line.split("|")
            bram_used = int(tmp[2].strip())
            bram_perc = float(tmp[6].strip())
        if "DSPs" in line:
            tmp = line.split("|")
            dsp_used = int(tmp[2].strip())
            dsp_perc = float(tmp[6].strip())
    with open(report, 'w') as f:
        f.write("Timing:\n")
        f.write("\tSlack:\t\t{:.3f}ns\n".format(slack))
        f.write("\tFrequency:\t{:.3f}MHz\n".format(freq))
        f.write("Resources:\n")
        f.write("\tLUTs:\t{} ({:.2f}%)\n".format(lut_used, lut_perc))
        f.write("\tRegs:\t{} ({:.2f}%)\n".format(ff_used, ff_perc))
        f.write("\tBRAM:\t{} ({:.2f}%)\n".format(bram_used, bram_perc))
        f.write("\tDSPs:\t{} ({:.2f}%)\n".format(dsp_used, dsp_perc))

if __name__=="__main__":
    if len(sys.argv) == 4:
        main(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        print("Usage: {} <timingReport> <resourceReport> <targetReport>".format(sys.argv[0]))
        exit(1)
