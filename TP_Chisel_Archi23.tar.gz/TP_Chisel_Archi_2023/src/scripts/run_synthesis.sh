#!/bin/bash

if [[ $XILINX_VIVADO = "" ]]; then
    echo "Vivado not setup. Cannot proceed"
    exit 1
fi

VIVADO=vivado
THIS_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
TMP_DIR=./tmp

PARSE_SCRIPT=$THIS_DIR/parse_report.py
SCRIPT_NAME=synth.tcl
SCRIPT=$THIS_DIR/$SCRIPT_NAME
TMP_SCRIPT=tmp/$SCRIPT_NAME

CONSTRAINTS=$THIS_DIR/constraints.xdc
TMP_CONSTRAINTS=$TMP_DIR/constraints.xdc

TIMING=timing.log

RESULT_FILE=resources.rpt
SYNTH_RESULT_DIR=synth_project/synth.runs/synth_1

RESULT_DIR=results

POSITIONAL_ARGS=()

while [[ $# -gt 0 ]]; do
  case $1 in
    -f|--file)
      VERILOG="$2"
      shift # past argument
      shift # past value
      ;;
    -v)
      VERBOSE=1
      shift
      ;;
    -*|--*)
      echo "Unknown option $1"
      exit 1
      ;;
    *)
      POSITIONAL_ARGS+=("$1") # save positional arg
      shift # past argument
      ;;
  esac
done

CUR_DATE=`date +"_%H_%M_%S"`
TOP_MODULE_NAME=$(basename $VERILOG .v)

TGT_DIR=$RESULT_DIR/$TOP_MODULE_NAME$CUR_DATE

TIMING=$TGT_DIR/timing.log
RESULT_FILE=$TGT_DIR/$RESULT_FILE
REPORT=$TGT_DIR/report.rpt

# sanitize file names
VERILOG_SAFE=$(echo $VERILOG | sed "s|/|\\\/|g")
TIMING_SAFE=$(echo $TIMING | sed "s|/|\\\/|g")
REPORT_SAFE=$(echo $REPORT | sed "s|/|\\\/|g")
VERILOG_BASE=$(basename -- $VERILOG)
LOCAL_VERILOG=verilog/$VERILOG_BASE
LOCAL_VERILOG_SAFE=$(echo $LOCAL_VERILOG | sed "s|/|\\\/|g")

if [[ $LOCAL_VERILOG = "" ]]; then
    echo "Error: did not specify input file (-f)"
    exit 1
fi

if test ! -f "$LOCAL_VERILOG"; then
    echo "Error: file $LOCAL_VERILOG does not exist"
    exit 1
fi

if [[ $REPORT = "" ]]; then
    echo "Error: did not specify report file (-r)"
    exit 1
fi


mkdir -p $TMP_DIR
mkdir -p $TGT_DIR

cp $SCRIPT $TMP_SCRIPT
cp $CONSTRAINTS $TMP_CONSTRAINTS

sed -i "s/TIMING_REPORT/$TIMING_SAFE/g" $TMP_SCRIPT
sed -i "s/TOP_MODULE/$LOCAL_VERILOG_SAFE/g" $TMP_SCRIPT

if [[ $VERBOSE = 1 ]]; then
    $VIVADO -mode batch -nolog -nojournal -source $TMP_SCRIPT
else
    $VIVADO -mode batch -nolog -nojournal -source $TMP_SCRIPT > /dev/null
fi

cp $SYNTH_RESULT_DIR/"$TOP_MODULE_NAME"_utilization_synth.rpt $RESULT_FILE
cp $LOCAL_VERILOG $TGT_DIR

python3 $PARSE_SCRIPT $TIMING $RESULT_FILE $REPORT

echo "========================================================"
echo "================== SYNTHESIS COMPLETE =================="
echo "========================================================"
echo "Synthesis results for file $VERILOG ($REPORT):"
cat $REPORT
echo "========================================================"
