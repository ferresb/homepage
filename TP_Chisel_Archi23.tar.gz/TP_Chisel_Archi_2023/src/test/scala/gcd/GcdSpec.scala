// See README.md for license details.

package gcd

import chisel3._
import chiseltest._
import org.scalatest.freespec.AnyFreeSpec
import chisel3.experimental.BundleLiterals._

class GcdSpec extends AnyFreeSpec with ChiselScalatestTester {

  "GCD should respect its spec" in {
    // Testing for every pair in [1, 10]x[1,10]
    test(new GCD).withAnnotations(Seq(WriteVcdAnnotation)) { dut =>
      val testValues = for { x <- 1 to 10; y <- 1 to 10} yield (x, y)

      for ((x, y) <- testValues) {
        // poking values on inputs during loading cycle
        dut.io.value1.poke(x)
        dut.io.value2.poke(y)
        dut.io.loadingValues.poke(true)
        dut.clock.step(1)
        // don't forget to stop loading
        dut.io.loadingValues.poke(false)
        // let the design compute in peace
        while (!dut.io.outputValid.peekBoolean()){
          dut.clock.step(1)
        }
        // validate the result against a golden reference
        dut.io.outputGCD.expect(BigInt(x).gcd(BigInt(y)))
      }
    }
  }
}
