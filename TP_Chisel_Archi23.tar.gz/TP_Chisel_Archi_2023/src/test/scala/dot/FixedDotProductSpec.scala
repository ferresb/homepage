package dot

import chisel3._
import chiseltest._
import org.scalatest.freespec.AnyFreeSpec

class FixedDotProductSpec extends AnyFreeSpec with ChiselScalatestTester {

  "Fixed Dot Product should compute a proper dot product" in {
    test(new FixedDotProduct).withAnnotations(Seq(WriteVcdAnnotation)) { dut =>
      val vecsize = 4
      for (i <- 0 until 10 by 10) {
        val testVec1 = DotProductUtils.generateInputs(vecsize, i, 2 * _)
        val testVec2 = DotProductUtils.generateInputs(vecsize, 2*i, _ + 1)
        val resultSeq = (testVec1 zip testVec2).map { case (x, y) => x * y }.reduce(_+_)

        for (j <- 0 until vecsize) {
          dut.io.vec1(j).poke(testVec1(j))
          dut.io.vec2(j).poke(testVec2(j))
        }

        dut.io.out.expect(resultSeq)
      }
    }
  }
  "Fixed Dot Product should fail on signed ints" in {
    test(new FixedDotProduct).withAnnotations(Seq(WriteVcdAnnotation)) { dut =>
      val vecsize = 4
      val testVec1 = DotProductUtils.generateInputs(vecsize, 0, 2 * _)
      val testVec2 = DotProductUtils.generateInputs(vecsize, 0, -_)
      val result = (testVec1 zip testVec2).map { case (x, y) => x * y }.reduce(_+_)

      try {
        for (j <- 0 until vecsize) {
          dut.io.vec1(j).poke(testVec1(j))
          dut.io.vec2(j).poke(testVec2(j))
        }

        dut.io.out.expect(result)
      } catch {
        case e: chisel3.internal.ChiselException =>  
        case e: Throwable => throw e
      }
    }
  }
}
