package dot

object DotProductUtils {
  def generateInputs(nb: Int, start: Int, pattern: Int => Int) = 
    (0 until nb).map(i => start + pattern(i))
}
