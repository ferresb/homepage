package dot

import chisel3._
import chisel3.experimental._
import chiseltest._
import org.scalatest.freespec.AnyFreeSpec
import chisel3.experimental.BundleLiterals._

class GenericDotProductSpec extends AnyFreeSpec with ChiselScalatestTester {

  val rand = new scala.util.Random

  /** probability of NOT inserting a nop cycle in the pipeline */
  val probPoke = 0.9

  /** check if should poke a new value, or insert a nop cycle */
  def doPoke: Boolean = rand.nextFloat() > (1 - probPoke)

  /** tester helper, to instanciate and test a ParametrizedDotProduct. */
  def myTesterUInt(config: DotProductConfig, nbTests: Int, maxValue: Int = 15) = { 
    val vecSize   = config.nElem
    val elemSize  = config.width
    val latency   = config.latency
    val fMul      = config.mulFunc
    val fAdd      = config.addFunc
    
    val tpe = UInt(elemSize.W)

    Console.println(f"Latency in ${config.name}%s = $latency%d")

    test(new GenericDotProduct[UInt](tpe, vecSize, fMul, fAdd, latency))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>
        val testVec1: Array[IndexedSeq[Int]] = Array.ofDim(nbTests)
        val testVec2: Array[IndexedSeq[Int]] = Array.ofDim(nbTests)
        val resultSeq: Array[BigInt] = Array.ofDim(nbTests)

        // Populate testing vectors
        for (i <- 0 until nbTests by 1) {
          // testVec1 will be populated with some random values
          testVec1(i) = DotProductUtils.generateInputs(vecSize, i, rand.nextInt(maxValue) + 0 * _)
          testVec2(i) = DotProductUtils.generateInputs(vecSize, 2*i, _ + 1)
          // software computation of the dot product
          resultSeq(i) = (testVec1(i) zip testVec2(i))
                          .map { case (x, y) => x * y }
                          .reduce(_+_)
        }
        /* As we now require to test some sequential behavior (synchronization 
         * of the pipeline with the inValid signal), we use parallel processes
         * for the test. One process will be poking inputs, the other one will
         * be checking results */
        fork {
          // process to poke input values, in a pipelined fashion
          var cur = 0
          while (cur < nbTests) {
            if (doPoke) {
              // this cycle, poke a new value on input vectors
              for (j <- 0 until vecSize) {
                dut.io.inValid.poke(true)
                dut.io.vec1(j).poke(testVec1(cur)(j))
                dut.io.vec2(j).poke(testVec2(cur)(j))
              }
              dut.clock.step(1)
              cur += 1
            } else {
              // insert nop cycles, just to check
              dut.io.inValid.poke(false)
              dut.clock.step(1)
            }
          }
        }.fork {
          // process to check output values
          for (cur <- 0 until nbTests by 1) {
            // skip to next cycle where ouput is valid
            while (!dut.io.outValid.peekBoolean()){
              dut.clock.step(1)
            }
            dut.io.out.expect(resultSeq(cur))
            dut.clock.step(1)
          }
        }.join()
      }
  }


  /** tester helper, to instanciate and test a ParametrizedDotProduct. */
  def myTesterFixedPoint(config: DotProductConfigFP, nbTests: Int, maxValue: Int = 15) = { 
    val vecSize   = config.nElem
    val elemSize  = config.width
    val latency   = config.latency
    val fMul      = config.mulFunc
    val fAdd      = config.addFunc
    
    val bp = elemSize / 2
    val tpe = FixedPoint(elemSize.W, bp.BP)

    Console.println(f"Latency in ${config.name}%s = $latency%d")

    test(new GenericDotProduct[FixedPoint](tpe, vecSize, fMul, fAdd, latency))
      .withAnnotations(Seq(WriteVcdAnnotation)) { dut =>
        val testVec1: Array[IndexedSeq[Int]] = Array.ofDim(nbTests)
        val testVec2: Array[IndexedSeq[Int]] = Array.ofDim(nbTests)
        val resultSeq: Array[BigDecimal] = Array.ofDim(nbTests)

        // Populate testing vectors
        for (i <- 0 until nbTests by 1) {
          // testVec1 will be populated with some random values
          testVec1(i) = DotProductUtils.generateInputs(vecSize, i, rand.nextInt(maxValue) + 0 * _)
          testVec2(i) = DotProductUtils.generateInputs(vecSize, 2*i, _ + 1)
          // software computation of the dot product
          resultSeq(i) = (testVec1(i) zip testVec2(i))
                          .map { case (x, y) => x * y }
                          .reduce(_+_)
        }

        /* As we now require to test some sequential behavior (synchronization 
         * of the pipeline with the inValid signal), we use parallel processes
         * for the test. One process will be poking inputs, the other one will
         * be checking results */
        fork {
          // process to poke input values, in a pipelined fashion
          var cur = 0
          while (cur < nbTests) {
              for (j <- 0 until vecSize) {
                dut.io.inValid.poke(true)
                dut.io.vec1(j).poke(testVec1(cur)(j))
                dut.io.vec2(j).poke(testVec2(cur)(j))
              }
              dut.clock.step(1)
              cur += 1
          }
        }.fork {
          // process to check output values
          for (cur <- 0 until nbTests by 1) {
            // skip to next cycle where ouput is valid
            while (!dut.io.outValid.peekBoolean()){
              dut.clock.step(1)
            }
            dut.io.out.expect(resultSeq(cur))
            dut.clock.step(1)
          }
        }.join()
      }
  }

  "Generic Dot Product with no pipeline" in {
    myTesterUInt(Config3, 10)
  }

  "Generic Dot Product with fixed point" in {
    myTesterFixedPoint(Config3FP, 10)
  }
}
