package gcd

object Emitter extends App {
  utils.emitVerilog(new GCD, "GCD")
}

object DecoupledEmitter extends App {
  utils.emitVerilog(new DecoupledGcd(32), "decoupledGCD")
}
