import chisel3._
import chisel3.stage.ChiselStage

package object utils {
  val target_directory = "verilog"
  def emitVerilog(gen: => RawModule, dir: String) = 
    (new ChiselStage).emitVerilog(gen, Array("--target-dir", target_directory + "/" + dir))
}
