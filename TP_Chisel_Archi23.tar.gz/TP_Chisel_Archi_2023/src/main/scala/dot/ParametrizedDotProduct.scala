package dot

import chisel3._
import chisel3.util._

class ParametrizedDotProduct(
  val width: Int,
  val nElem: Int,
  val mulFunc: (UInt, UInt) => UInt,
  val addFunc: (UInt, UInt) => UInt,
  val latency : Int
) extends Module {
  require(nElem > 0, "nElem should at least be 1")
  require(width > 0, "width should at least be 1")
  require(latency >= 0, "totalLatency should be positive")

  // declare the type of data we're working with. Width is parametric.
  val tpe = UInt(width.W)

  // declare the IO bundle. Inputs are parametric vectors.
  val io  = IO(new Bundle {
    val vec1 = Input(Vec(nElem, tpe))
    val vec2 = Input(Vec(nElem, tpe))
    val inValid = Input(Bool())
    val out  = Output(UInt())
    val outValid = Output(Bool())
  })

  // should be the total latency of the circuit
  val totalLatency = latency + 2

  // buffer input ports in registers.
  // (this adds one latency cycle to the total latency)
  val vec1Buffered = RegNext(io.vec1)
  val vec2Buffered = RegNext(io.vec2)

  // INSTRUCTION: Use this signal to define when the output of the circuit 
  // is valid, with respect to the input signals and the total latency.
  io.outValid := ???

  // INSTRUCTION: Replace this declaration to assign to outBuffer the 
  // result of the dot product computation. 
  val outBuffer = Reg(???)

  // assign the output of the outBuffer register to io.out.
  // this makes it possible to buffer the output signal.
  // (this adds one latency cycle to the total latency)
  io.out := outBuffer
}
