package dot

import scala.math.log10
import chisel3._
import chisel3.util._
import chisel3.experimental._

object Utils {
  def log2Ceil(x: Int) = (log10(x.toFloat) / log10(2.0)).ceil.toInt

  def fAddSimple(a: UInt, b: UInt) = a + b
  def fMulSimple(a: UInt, b: UInt) = a * b

  /* pipelined addition */
  def fAddReg(a: UInt, b: UInt) = RegNext(a + b)
  /* pipelined multiplication */
  def fMulReg(a: UInt, b: UInt) = RegNext(a * b)
  /* DSP optimized multiplication */
  def fMulDSP(a: UInt, b: UInt) = ShiftRegister(a * b, 3)

  /* pipelined addition */
  def fAddRegFP(a: FixedPoint, b: FixedPoint) = RegNext(a + b)
  /* pipelined multiplication */
  def fMulRegFP(a: FixedPoint, b: FixedPoint) = RegNext(a * b)

  def computeLatency(nElem: Int, mul: Int, add: Int) =
    mul + log2Ceil(nElem)*add
}
