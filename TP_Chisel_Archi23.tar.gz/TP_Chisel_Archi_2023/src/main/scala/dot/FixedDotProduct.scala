package dot

import chisel3._

class FixedDotProduct extends Module {
  val io = IO(new Bundle {
    val vec1 = Input(Vec(4, UInt(8.W)))
    val vec2 = Input(Vec(4, UInt(8.W)))
    val out  = Output(UInt())
  })

  val mult = Wire(Vec(4, UInt(16.W)))
  val tmp1 = Wire(UInt())
  val tmp2 = Wire(UInt())
  for (i <- 0 until 4) {
    mult(i) := ???
  }
  tmp1 := ???
  tmp2 := ???
  io.out := ???
}
