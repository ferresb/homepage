package dot

import chisel3._
import chisel3.experimental._

object FixedEmitter extends App {
  utils.emitVerilog(new FixedDotProduct, "fixed")
}

object ParametrizedUtils {
  def emit(config: DotProductConfig) =
    utils.emitVerilog(new ParametrizedDotProduct(
      config.width,
      config.nElem,
      config.mulFunc,
      config.addFunc,
      config.latency
    ), config.name)
}

object ParametrizedEmitterConfig1 extends App {
  ParametrizedUtils.emit(Config1)
}

object ParametrizedEmitterConfig2 extends App {
  ParametrizedUtils.emit(Config2)
}

object ParametrizedEmitterConfig3 extends App {
  ParametrizedUtils.emit(Config3)
}

object ParametrizedEmitterConfig3DSP extends App {
  ParametrizedUtils.emit(Config3DSP)
}

object ParametrizedEmitterConfig4 extends App {
  ParametrizedUtils.emit(Config4)
}

object GenericUtilsUInt {
  def emit(config: DotProductConfig) =
    utils.emitVerilog(new GenericDotProduct[UInt](
      UInt(config.width.W),
      config.nElem,
      config.mulFunc,
      config.addFunc,
      config.latency
    ), config.name)
}

object GenericEmitterConfig3 extends App {
  GenericUtilsUInt.emit(Config3)
}

object GenericUtilsFP {
  def emit(config: DotProductConfigFP) =
    utils.emitVerilog(new GenericDotProduct[FixedPoint](
      FixedPoint(config.width.W, (config.width/2).BP),
      config.nElem,
      config.mulFunc,
      config.addFunc,
      config.latency
    ), config.name)
}

object GenericEmitterConfig3FP extends App {
  GenericUtilsFP.emit(Config3FP)
}
