package dot

import chisel3._
import chisel3.experimental._

class DotProductConfig (
  val name: String,
  val width: Int,
  val nElem: Int,
  val mulFunc: (UInt, UInt) => UInt,
  val addFunc: (UInt, UInt) => UInt,
  val latency : Int
)

object Config1 extends DotProductConfig (
  "paramConfig1",
  8,
  4,
  Utils.fMulSimple,
  Utils.fAddSimple,
  Utils.computeLatency(4, 0, 0)
)

object Config2 extends DotProductConfig (
  "paramConfig2",
  8,
  4,
  Utils.fMulReg,
  Utils.fAddReg,
  Utils.computeLatency(4, 1, 1)
)

object Config2NoPowerOfTwo extends DotProductConfig (
  "paramConfig2NoPow2",
  8,
  6,
  Utils.fMulReg,
  Utils.fAddReg,
  Utils.computeLatency(4, 1, 1)
)

object Config3 extends DotProductConfig (
  "paramConfig3",
  32,
  16,
  Utils.fMulReg,
  Utils.fAddReg,
  Utils.computeLatency(16, 1, 1)
)

object Config3DSP extends DotProductConfig (
  "paramConfig3DSP",
  32,
  16,
  Utils.fMulDSP,
  Utils.fAddReg,
  Utils.computeLatency(16, 3, 1)
)

object Config4 extends DotProductConfig (
  "paramConfig4",
  32,
  128,
  Utils.fMulReg,
  Utils.fAddReg,
  Utils.computeLatency(128, 1, 1)
)

class DotProductConfigFP (
  val name: String,
  val width: Int,
  val nElem: Int,
  val mulFunc: (FixedPoint, FixedPoint) => FixedPoint,
  val addFunc: (FixedPoint, FixedPoint) => FixedPoint,
  val latency : Int
)

object Config3FP extends DotProductConfigFP (
  "paramConfig3FP",
  32,
  16,
  Utils.fMulRegFP,
  Utils.fAddRegFP,
  Utils.computeLatency(16, 1, 1)
)

