package dot

import chisel3._
import chisel3.util._

class GenericDotProduct[T <: Data with Num[T]](
  val tpe: T,
  val nElem: Int,
  val mulFunc: (T, T) => T,
  val addFunc: (T, T) => T, 
  val latency : Int
) extends Module {
  val io  = IO(new Bundle {
    val vec1 = Input(Vec(nElem, tpe))
    val vec2 = Input(Vec(nElem, tpe))
    val inValid = Input(Bool())
    val out  = Output(tpe)
    val outValid = Output(Bool())
  })

  // should be the total latency of the circuit
  val totalLatency = latency + 2

  // buffer input ports in registers.
  // (this adds one latency cycle to the total latency)
  val vec1Buffered = RegNext(io.vec1)
  val vec2Buffered = RegNext(io.vec2)

  // INSTRUCTION: Use this signal to define when the output of the circuit 
  // is valid, with respect to the input signals and the total latency.
  io.outValid := ???

  // INSTRUCTION: Replace this declaration to assign to outBuffer the 
  // result of the dot product computation. 
  val outBuffer = Reg(???)

  // assign the output of the outBuffer register to io.out.
  // this makes it possible to buffer the output signal.
  // (this adds one latency cycle to the total latency)
  io.out := outBuffer
}
